
export interface QuestionOption {
  value: string;
  label: string;
}

export interface Question {
  id: string;
  type: 'text' | 'textarea' | 'radio' | 'checkbox' | 'select';
  label: string;
  description?: string;
  options?: QuestionOption[];
  required?: boolean;
}

export interface Section {
  id: string;
  title: string;
  description: string;
  questions: Question[];
}

export type FormData = Record<string, string | string[]>;
