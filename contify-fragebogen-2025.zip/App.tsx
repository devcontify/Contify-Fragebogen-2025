import React, { useState, useMemo } from 'react';
import { sections } from './constants';
import { type FormData } from './types';
import QuestionnaireSection from './components/QuestionnaireSection';
import ProgressBar from './components/ProgressBar';
import SubmissionSummary from './components/SubmissionSummary';

const App: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({});
  const [activeSectionIndex, setActiveSectionIndex] = useState<number | null>(0);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const totalQuestions = useMemo(() => sections.reduce((acc, section) => acc + section.questions.length, 0), []);
  
  const answeredQuestions = useMemo(() => {
    return Object.values(formData).filter(value => value !== '' && value !== undefined && value !== null && (!Array.isArray(value) || value.length > 0)).length;
  }, [formData]);

  const progress = useMemo(() => {
    if (totalQuestions === 0) return 0;
    return Math.round((answeredQuestions / totalQuestions) * 100);
  }, [answeredQuestions, totalQuestions]);

  const handleToggleSection = (index: number) => {
    setActiveSectionIndex(prevIndex => (prevIndex === index ? null : index));
  };

  const handleChange = (questionId: string, value: string | string[]) => {
    setFormData(prevData => ({ ...prevData, [questionId]: value }));
    if (errors[questionId]) {
        const newErrors = { ...errors };
        delete newErrors[questionId];
        setErrors(newErrors);
    }
  };
  
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};
    sections.forEach(section => {
      section.questions.forEach(q => {
        if (q.required && (!formData[q.id] || formData[q.id]?.length === 0)) {
          newErrors[q.id] = 'This field is required.';
        }
      });
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setIsSubmitted(true);
      window.scrollTo(0, 0);
    } else {
        const firstErrorKey = Object.keys(errors)[0];
        if (firstErrorKey) {
            const errorElement = document.getElementById(firstErrorKey);
            errorElement?.focus();
            const errorSectionIndex = sections.findIndex(sec => sec.questions.some(q => q.id === firstErrorKey));
            if(errorSectionIndex !== -1 && activeSectionIndex !== errorSectionIndex) {
                setActiveSectionIndex(errorSectionIndex);
            }
        }
    }
  };
  
  const handleReset = () => {
    setFormData({});
    setIsSubmitted(false);
    setActiveSectionIndex(0);
    setErrors({});
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-slate-100/50 font-sans text-slate-800">
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900">Contify Fragebogen 2025 - Professionelle Textprojekte</h1>
          <p className="text-sm sm:text-base text-slate-600 mt-1">Fragebogen zur Beauftragung von Textprojekten.</p>
        </div>
      </header>
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg overflow-hidden">
          {isSubmitted ? (
            <SubmissionSummary formData={formData} onReset={handleReset} />
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div className="p-6 sm:p-8">
                <h2 className="text-xl font-semibold text-slate-800">Fortschritt</h2>
                <ProgressBar progress={progress} />
              </div>
              
              <div className="border-t border-slate-200">
                {sections.map((section, index) => (
                  <QuestionnaireSection
                    key={section.id}
                    section={section}
                    isOpen={activeSectionIndex === index}
                    onToggle={() => handleToggleSection(index)}
                    formData={formData}
                    onChange={handleChange}
                    errors={errors}
                  />
                ))}
              </div>

              <div className="p-6 sm:p-8 bg-slate-50 border-t border-slate-200">
                <div className="flex flex-col sm:flex-row justify-end items-center gap-4">
                  <div className="text-sm text-slate-600">
                    <p>
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline mr-1" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 1a4.5 4.5 0 00-4.5 4.5V9H5a2 2 0 00-2 2v6a2 2 0 002 2h10a2 2 0 002-2v-6a2 2 0 00-2-2h-.5V5.5A4.5 4.5 0 0010 1zm3 8V5.5a3 3 0 10-6 0V9h6z" clipRule="evenodd" />
                      </svg>
                      Ihre Daten werden nur lokal in Ihrem Browser verarbeitet und nicht an einen Server gesendet.
                    </p>
                  </div>
                  <button
                    type="submit"
                    className="w-full sm:w-auto bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200 shadow-md"
                  >
                    Analyse abschließen
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </main>
      
      <footer className="text-center py-6 text-slate-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Contify - Die Textagentur</p>
      </footer>
    </div>
  );
};

export default App;