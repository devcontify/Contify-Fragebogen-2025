
import React from 'react';
import { type Section, type FormData, type Question } from '../types';
import { ChevronDownIcon, ChevronUpIcon } from './icons';

interface QuestionnaireSectionProps {
  section: Section;
  isOpen: boolean;
  onToggle: () => void;
  formData: FormData;
  onChange: (questionId: string, value: string | string[]) => void;
  errors: Record<string, string>;
}

const FormField: React.FC<{ question: Question, value: any, onChange: (id: string, value: any) => void, error?: string }> = ({ question, value, onChange, error }) => {
  const commonInputClass = "mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500";
  const errorClass = error ? "border-red-500 ring-red-500" : "";

  const renderInput = () => {
    switch (question.type) {
      case 'text':
        return <input id={question.id} type="text" value={value || ''} onChange={(e) => onChange(question.id, e.target.value)} className={`${commonInputClass} ${errorClass}`} />;
      case 'textarea':
        return <textarea id={question.id} value={value || ''} onChange={(e) => onChange(question.id, e.target.value)} rows={4} className={`${commonInputClass} ${errorClass}`} />;
      case 'select':
        return (
          <select id={question.id} value={value || ''} onChange={(e) => onChange(question.id, e.target.value)} className={`${commonInputClass} ${errorClass}`}>
            <option value="" disabled>Bitte wählen...</option>
            {question.options?.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
          </select>
        );
      case 'radio':
        return (
          <div className="mt-2 space-y-2">
            {question.options?.map(opt => (
              <label key={opt.value} className="flex items-center p-3 border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer">
                <input type="radio" name={question.id} value={opt.value} checked={value === opt.value} onChange={(e) => onChange(question.id, e.target.value)} className="h-4 w-4 text-indigo-600 border-slate-300 focus:ring-indigo-500" />
                <span className="ml-3 text-sm text-slate-700">{opt.label}</span>
              </label>
            ))}
          </div>
        );
      case 'checkbox':
        const handleCheckboxChange = (optionValue: string) => {
          const currentValues = Array.isArray(value) ? value : [];
          const newValues = currentValues.includes(optionValue)
            ? currentValues.filter(v => v !== optionValue)
            : [...currentValues, optionValue];
          onChange(question.id, newValues);
        };
        return (
          <div className="mt-2 space-y-2">
            {question.options?.map(opt => (
              <label key={opt.value} className="flex items-center p-3 border border-slate-200 rounded-md hover:bg-slate-50 cursor-pointer">
                <input type="checkbox" value={opt.value} checked={Array.isArray(value) && value.includes(opt.value)} onChange={() => handleCheckboxChange(opt.value)} className="h-4 w-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500" />
                <span className="ml-3 text-sm text-slate-700">{opt.label}</span>
              </label>
            ))}
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="mb-6 last:mb-0">
      <label htmlFor={question.type !== 'radio' && question.type !== 'checkbox' ? question.id : undefined} className="block text-sm font-medium text-slate-800">
        {question.label} {question.required && <span className="text-red-500">*</span>}
      </label>
      {question.description && <p className="mt-1 text-xs text-slate-500">{question.description}</p>}
      {renderInput()}
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
};

const QuestionnaireSection: React.FC<QuestionnaireSectionProps> = ({ section, isOpen, onToggle, formData, onChange, errors }) => {
  return (
    <div className="border-b border-slate-200 last:border-b-0">
      <button
        type="button"
        className="w-full flex justify-between items-center p-6 sm:p-8 text-left hover:bg-slate-50 focus:outline-none focus:bg-slate-100"
        onClick={onToggle}
        aria-expanded={isOpen}
      >
        <div>
          <h3 className="text-lg font-semibold text-slate-900">{section.title}</h3>
          <p className="text-sm text-slate-500 mt-1">{section.description}</p>
        </div>
        {isOpen ? <ChevronUpIcon /> : <ChevronDownIcon />}
      </button>
      <div className={`${isOpen ? 'max-h-screen' : 'max-h-0'} overflow-hidden transition-max-height duration-700 ease-in-out`}>
        <div className="p-6 sm:p-8 border-t border-slate-200 bg-slate-50/50">
          {section.questions.map(q => (
            <FormField key={q.id} question={q} value={formData[q.id]} onChange={onChange} error={errors[q.id]} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuestionnaireSection;
