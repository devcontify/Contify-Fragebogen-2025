import React from 'react';
import { type FormData } from '../types';
import { sections } from '../constants';

interface SubmissionSummaryProps {
  formData: FormData;
  onReset: () => void;
}

const SubmissionSummary: React.FC<SubmissionSummaryProps> = ({ formData, onReset }) => {
  const getAnswerDisplay = (questionId: string, value: string | string[]): string => {
    const question = sections.flatMap(s => s.questions).find(q => q.id === questionId);
    if (!question) return Array.isArray(value) ? value.join(', ') : value;

    if (Array.isArray(value)) {
      return value.map(val => question.options?.find(opt => opt.value === val)?.label || val).join(', ');
    }
    
    return question.options?.find(opt => opt.value === value)?.label || value;
  };
  
  const downloadCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Section,Question,Answer\r\n";

    sections.forEach(section => {
      section.questions.forEach(question => {
        const answer = formData[question.id];
        const formattedAnswer = Array.isArray(answer) ? answer.join('; ') : answer || '';
        const row = [
          `"${section.title.replace(/"/g, '""')}"`,
          `"${question.label.replace(/"/g, '""')}"`,
          `"${formattedAnswer.replace(/"/g, '""')}"`
        ].join(',');
        csvContent += row + "\r\n";
      });
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "contify_fragebogen_textprojekte_2025.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 sm:p-8">
      <div className="text-center mb-8">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h2 className="text-2xl font-bold text-slate-900 mt-4">Vielen Dank!</h2>
        <p className="text-slate-600 mt-2">Ihre Antworten wurden erfolgreich erfasst. Hier ist eine Zusammenfassung Ihrer Eingaben.</p>
      </div>

      <div className="space-y-6">
        {sections.map(section => (
          <div key={section.id} className="bg-slate-50 rounded-lg p-4">
            <h3 className="text-lg font-semibold text-slate-800 border-b border-slate-200 pb-2 mb-3">{section.title}</h3>
            <ul className="space-y-3">
              {section.questions.map(q => (
                <li key={q.id}>
                  <p className="font-medium text-sm text-slate-700">{q.label}</p>
                  <p className="text-sm text-indigo-700 bg-indigo-50 p-2 rounded-md mt-1">
                    {getAnswerDisplay(q.id, formData[q.id]) || <span className="text-slate-400 italic">Keine Antwort</span>}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row justify-center items-center gap-4">
        <button
          onClick={downloadCSV}
          className="w-full sm:w-auto bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors duration-200 shadow-md flex items-center justify-center gap-2"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
          Als CSV herunterladen
        </button>
        <button
          onClick={onReset}
          className="w-full sm:w-auto bg-slate-200 text-slate-800 font-bold py-3 px-6 rounded-lg hover:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-400 transition-colors duration-200"
        >
          Fragebogen zurücksetzen
        </button>
      </div>
    </div>
  );
};

export default SubmissionSummary;